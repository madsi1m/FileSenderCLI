Filesender
=========

Filesender is used to send files to remote site.

Optional Dependencies
---------------------


Installation
------------

Install Python (>=3.4)
~~~~~~~~~~~~~~~~~~~~~~

